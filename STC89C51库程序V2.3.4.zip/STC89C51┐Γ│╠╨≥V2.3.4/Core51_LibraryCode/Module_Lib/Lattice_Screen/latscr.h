#ifndef __LATSCR_H_
#define __LATSCR_H_


#include <reg52.h>
#include <intrins.h>
#include "delay.h"



#endif